const router = require("express").Router();
const paypalController = require('../controllers/paypalController');
const { body, validationResult } = require(`express-validator`);

router.post('/pay', [
    body('puppiename', "Enter a valid Puppie Name").notEmpty(),
    body(`amount`, "Enter a valid Puppie Amount").notEmpty()
], paypalController.paypal_payment);

router.get('/success', paypalController.paypal_success);

router.get('/cancel', paypalController.paypal_cancel);



module.exports = router;