const Payment = require("../models/Payment");
const { validationResult } = require(`express-validator`);


const payment_all = async (req, res) => {
    try {
        const payment = await Payment.find();
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};

const payment_details = async (req, res) => {
    try {
        const payment = await Puppie.findById(req.params.paymentId);
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};

const payment_create = async (req, res) => {
    let success = false;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success, errors: errors.array() });
    }
    console.log("Hello");
    console.log(req.body.transactionId);
    console.log(req.body.firstName);
    var payments = Payment.create(
        {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            company: req.body.company,
            country: req.body.country,
            postalCode: req.body.postalCode,
            city: req.body.city,
            address: req.body.address,
            state: req.body.state,
            phone: req.body.phone,
            email: req.body.email,
            comment: req.body.comment,
            puppieName: req.body.puppieName,
            puppieAmount: req.body.puppieAmount,
            orderId: req.body.orderId,
            transactionId: req.body.transactionId,
            paymentStatus: req.body.paymentStatus,
            shippingStatus: req.body.shippingStatus,
            date: req.body.date
        }
    ).then(
        res.json("Details have been Successfully Saved")
    )
        .catch(err => {
            console.log(err);
            res.setHeader('Content-Type', 'application/json');
            res.json("Internal Server Error");
        }
        );
};







const payment_update = async (req, res) => {
    try {
        const payment = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            company: req.body.company,
            country: req.body.country,
            postalCode: req.body.postalCode,
            city: req.body.city,
            address: req.body.address,
            state: req.body.state,
            phone: req.body.phone,
            email: req.body.email,
            comment: req.body.comment,
            puppieName: req.body.puppieName,
            puppieAmount: req.body.puppieAmount,
            orderId: req.body.orderId,
            transactionId: req.body.transactionId,
            paymentStatus: req.body.paymentStatus,
            shippingStatus: req.body.shippingStatus,
            date: req.body.date
        };

        const updatedPayment = await Payment.findByIdAndUpdate(
            { _id: req.params.paymentId },
            payment
        );
        res.json(updatedPayment);
    } catch (error) {
        res.json({ message: error });
    }
};




const payment_delete = async (req, res) => {
    try {
        const payment = await Payment.findByIdAndDelete(req.params.paymentId);
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};



const payment_by_transactionId = async (req, res) => {
    console.log("Hi");
    try {
        const payment = await Payment.findOne({ transactionId: req.params.transactionId });
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};

const paymentByShipping = async (req, res) => {
    try {
        const payment = await Payment.find({ shippingStatus: req.params.shippingStatus });
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};


const paymentByPayment = async (req, res) => {
    try {
        const payment = await Payment.find({ paymentStatus: req.params.paymentStatus });
        res.json(payment);
    } catch (error) {
        res.json({ message: error });
    }
};


module.exports = {
    payment_all,
    payment_details,
    payment_create,
    payment_update,
    payment_delete,
    payment_by_transactionId,
    paymentByShipping,
    paymentByPayment
}