const paypal = require("paypal-rest-sdk");

paypal.configure({
    mode: "sandbox", //sandbox or live
    client_id:
        "AZfNIXo5CPTD8gJEyzWPqz6AkxvNMK9W76xh5Z7Tts-8atM0aPvTEPcx-S7uAPIU5ZZX9iyfMT3DOurt",
    client_secret:
        "EDsGpEKNiHI-wr6OwqWkr9mRbDumHdJInnIli6O6F2RNiCdqNFsFunnXQmRZBFr1O70Bk9NBG0gjHxRu",
});





const paypal_payment = async (req, res) => {
    var money = req.body.amount;
    var puppieName = req.body.puppiename;
    console.log(money);
    const create_payment_json = {
        intent: "sale",
        payer: {
            payment_method: "paypal",
        },
        redirect_urls: {
            return_url: "http://puppies-env.eba-ws5rvcc8.ap-south-1.elasticbeanstalk.com/success?money=" + money,
            cancel_url: "http://puppies-env.eba-ws5rvcc8.ap-south-1.elasticbeanstalk.com/cancel",
        },
        transactions: [
            {
                item_list: {
                    items: [
                        {
                            name: puppieName,
                            sku: "001",
                            price: money,
                            currency: "USD",
                            quantity: 1,
                        },
                    ],
                },
                amount: {
                    currency: "USD",
                    total: money,
                },
                description: "This payment is accepted by the payment website.",
            },
        ],
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            //throw error;
            console.log(error);
        } else {
            for (let i = 0; i < payment.links.length; i++) {
                if (payment.links[i].rel === "approval_url") {
                    // res.redirect(payment.links[i].href);
                    res.status(200).send({ link: payment.links[i].href });
                }
            }
        }
    }
    )
};

const paypal_success = async (req, res) => {
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const amount = req.query.money;

    const execute_payment_json = {
        payer_id: payerId,
        transactions: [
            {
                amount: {
                    currency: "USD",
                    total: amount,
                },
            },
        ],
    };
    try {
        paypal.payment.execute(
            paymentId,
            execute_payment_json,
            function (error, payment) {
                if (error) {
                    console.log(error.response);
                    //throw error;
                } else {
                   // console.log(JSON.stringify(payment));
                    //console.log(payment);
                    //  res.send("Success");
                    res.status(200).send(payment);
                    // res.status(200).send( [payment]);
                }
            }
        );
    }
    catch (e) {
        console.log(e);
    }
};


const paypal_cancel = async (req, res) => res.send('Cancelled');


module.exports = {
    paypal_payment,
    paypal_success,
    paypal_cancel
}

